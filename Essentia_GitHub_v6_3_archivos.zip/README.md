# Condominio Essentia — Potosí

Versión web separada en tres archivos para GitHub Pages:

- `index.html` — estructura y contenido
- `style.css` — estilos
- `script.js` — interacciones y galerías

Sube los tres archivos a la raíz del repositorio de GitHub.
